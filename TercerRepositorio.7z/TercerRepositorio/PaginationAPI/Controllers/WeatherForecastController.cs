using Microsoft.AspNetCore.Mvc;
using PaginationProgram;

namespace PaginationAPI.Controllers
{
    [ApiController]
    [Route("Pagination")]
    public class PaginationController : ControllerBase
    {
        [HttpPost]
        [Route("PaginationTest")]

        public dynamic PaginationTest(int currentPage, int totalPages)
        {
            Pagination pagination = new Pagination();
            InputProgram.Input currentPage2 = new InputProgram.Input(currentPage);
            InputProgram.Input totalPages2 = new InputProgram.Input(totalPages);
            OutputProgram.Output output = pagination.Result(currentPage2, totalPages2);
            return output.getResult();
        }
    }
}
